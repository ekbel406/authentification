#include <gtk/gtk.h>


void
on_buttonAjouter_clicked               (GtkButton       *button,
                                        gpointer         user_data);
